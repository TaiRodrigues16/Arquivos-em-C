#include<stdio.h>
#include<stdlib.h>

// Aluna: Taiane Aparecida Rodrigues      1� Per�odo de SI
/*
4. Escrever um algoritmo que leia o nome de um vendedor, o seu sal�rio fixo e o total de vendas efetuadas por ele no
m�s (em dinheiro). Sabendo que este vendedor ganha 15% de comiss�o sobre suas vendas efetuadas, informar o
seu nome, o sal�rio fixo e sal�rio no final do m�s.

*/

main(){
	char nome[200];
	float salario, vendas, totalvendas, salarioTotal;

	printf("Digite o nome do vendedor: ");
	scanf("%s",&nome);
	printf("\nDigite o seu salario: ");
	scanf("%f",&salario);
	printf("\nDigite o total de vendas em dinheiro: ");
	scanf("%f",&vendas);

	totalvendas = vendas * 0.15;
	salarioTotal = salario + totalvendas;

	printf("\n\nO nome do vendedor eh: %s",&nome);
	printf("\n\nO salario fixo do vendedor eh: %.2f",salario);
	printf("\n\nO salario total do vendedor eh: %.2f",salarioTotal);





}
