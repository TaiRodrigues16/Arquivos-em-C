#include<stdio.h>
#include<stdlib.h>

// Aluna: Taiane Aparecida Rodrigues      1� Per�odo de SI
/*
19. Escrever um algoritmo que leia o nome e o sexo de 56 pessoas e informe o nome e se ela � homem ou mulher. No
final informe total de homens e de mulheres.

*/

main(){

	int i,cont1,cont;
	char nome[50],sexo;

	cont1 = 0;
	cont = 0;

	for(i=0;i<56;i++){
		printf("\nDigite o nome da pessoa: ");
		scanf("%s",&nome);
		printf("\nDigite o sexo da pessoa: (F/M)\n");
		scanf("%s",&sexo);
        cont = cont + 1;

		if((sexo == 'F')||(sexo == 'f')){
			printf("\nO nome eh: %s",&nome);
			printf("\nO sexo eh feminino!\n",sexo);
			cont1 = cont1 + 1;
		}
		if((sexo == 'M')||(sexo == 'm')){
			printf("\nO nome eh: %s",&nome);
			printf("\nO sexo eh masculino!\n",sexo);
		}
	}
    //printf("\n%d",cont);
	printf("\nO total de homens eh: %d",cont-cont1);
	printf("\nO total de mulheres eh: %d",cont1);

}
