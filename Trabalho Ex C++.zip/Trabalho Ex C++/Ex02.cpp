#include<stdio.h>
#include<stdlib.h>

// Aluna: Taiane Aparecida Rodrigues      1� Per�odo de SI
/*
2. Fa�a um algoritmo que receba dois n�meros e ao final mostre a soma, subtra��o, multiplica��o e a divis�o dos
n�meros lidos.
*/

main(){

	float num1,num2,soma,sub,div,mult;

	printf("Digite o primeiro numero: ");
	scanf("%f",&num1);
	printf("\nDigite o segundo numero: ");
	scanf("%f",&num2);

	soma = num1 + num2;
	sub =  num1 - num2;
	mult = num1 * num2;
	div =  num1 / num2;

	printf("\n\nO resultado da soma eh: %.2f",soma);
	printf("\n\nO resultado da subtracao eh: %.2f",sub);
	printf("\n\nO resultado da multiplicacao eh: %.2f",mult);
	printf("\n\nO resultado da divisao eh: %.2f",div);

}
