#include<stdlib.h>
#include<stdio.h>

// Aluna: Taiane Aparecida Rodrigues      1� Per�odo de SI
/*
13. Fa�a um algoritmo que receba um n�mero e mostre uma mensagem caso este n�mero seja maior que 10.
*/

main(){

	float num;

	printf("Digite um numero: ");
	scanf("%f",&num);

	if(num > 10){
		printf("\nEste numero eh maior que 10!\n");
	}

}
