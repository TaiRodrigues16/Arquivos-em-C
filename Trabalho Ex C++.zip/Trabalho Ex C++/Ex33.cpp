#include<stdio.h>
#include<stdlib.h>

// Aluna: Taiane Aparecida Rodrigues      1� Per�odo de SI
/*
33. Escrever um algoritmo que leia tr�s valores inteiros e verifique se eles podem ser os lados de um tri�ngulo. Se
forem, informar qual o tipo de tri�ngulo que eles formam: equil�tero, is�scele ou escaleno.
Propriedade: o comprimento de cada lado de um tri�ngulo � menor do que a soma dos comprimentos dos outros
dois lados.
Tri�ngulo Equil�tero: aquele que tem os comprimentos dos tr�s lados iguais;
Tri�ngulo Is�scele: aquele que tem os comprimentos de dois lados iguais. Portanto, todo tri�ngulo equil�tero �
tamb�m is�scele;
Tri�ngulo Escaleno: aquele que tem os comprimentos de seus tr�s lados diferentes.
*/

main(){

    int num1, num2, num3;

    printf("\nDigite o primeiro valor: ");
    scanf("%d",&num1);
    printf("\nDigite o segundo valor: ");
    scanf("%d",&num2);
    printf("\nDigite o terceiro valor: ");
    scanf("%d",&num3 );

    if ((num1 < (num2 + num3))&&(num2 < (num1 + num3))&&(num3 < (num2 + num1))){
       if((num1 == num2)&&(num1 == num3)&&(num2 == num3)){
            printf("\n\nForma os lados de um: ");
            printf("\n -> Triangulo Equilatero!\n\n");
       }
       else if((num1 == num2)||(num1 == num3)||(num2 == num3)){
            printf("\n\nForma os lados de um: ");
            printf("\n -> Triangulo Isosceles!\n\n");
       }
       else if((num1 != num2)&&(num1 != num3)&&(num2 != num3)){
            printf("\n\nForma os lados de um: ");
            printf("\n -> Triangulo Escaleno!\n\n");
       }
    }else{
        printf("\n\nNao forma os lados de um triangulo! :/ \n\n");
    }
}
