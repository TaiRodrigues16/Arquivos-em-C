#include<stdio.h>
#include<stdlib.h>

// Aluna: Taiane Aparecida Rodrigues      1� Per�odo de SI
/*
21. Escrever um algoritmo que leia os dados de �N� pessoas (nome, sexo, idade e sa�de) e informe se est� apta ou n�o
para cumprir o servi�o militar obrigat�rio. Informe os totais.

*/

main(){

    int num,idade,i,cont;
    char nome[50],sexo,saude;

    cont = 0;

    printf("Digite a quantidade de pessoas: ");
    scanf("%d",&num);

    for(i=0;i < num;i++){
        printf("\nDigite o nome da pessoa: ");
        scanf("%s",&nome);
        printf("\nDigite a idade da pessoa: ");
        scanf("%d",&idade);
        printf("\nDigite o sexo da pessoa (F/M): ");
        scanf("%s",&sexo);
        printf("\nDigite saude da pessoa:");
        printf("\nB -> Boa");
        printf("\nR -> Ruim");
        printf("\nM -> Media\n");
        scanf("%s",&saude);

        if ((sexo=='M','m') && (idade>=18) && (saude=='B','b')){
                printf("\nEsta apta a cumprir o servico militar!");
                cont = cont + 1;
        }else{
            printf("\nNao esta apta a cumprir o servico militar!");
        }
    }

    printf("\nSao %d pessoa aptas!",cont);
    printf("\nA quantidade de pessoas Nao aptas eh: %d",num - cont);

    system("pause");
}
