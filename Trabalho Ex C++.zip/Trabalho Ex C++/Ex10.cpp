#include<stdlib.h>
#include<stdio.h>

// Aluna: Taiane Aparecida Rodrigues      1� Per�odo de SI
/*
10. A Loja Mam�o com A��car est� vendendo seus produtos em 5 (cinco) presta��es sem juros. Fa�a um algoritmo que
receba um valor de uma compra e mostre o valor das presta��es.

*/

main(){
	float valorCompra, valorPrest;

	printf("Digite o valor da compra: ");
	scanf("%f",&valorCompra);

	valorPrest = valorCompra / 2;

	printf("\n\nO valor de cada prestacao eh de: %.2f",valorPrest);

}
