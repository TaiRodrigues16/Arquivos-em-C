#include<stdio.h>
#include<stdlib.h>

// Aluna: Taiane Aparecida Rodrigues      1� Per�odo de SI
/*
35. Elabore um algoritmo que, dada a idade de um nadador. Classifique-o em uma das seguintes categorias:
Infantil A = 5 - 7 anos
Infantil B = 8 - 10 anos
juvenil A = 11- 13 anos
juvenil B = 14 - 17 anos
S�nior = 18 - 25 anos
Apresentar mensagem �idade fora da faixa et�ria� quando for outro ano n�o contemplado.

*/

main(){

    int idade;

    printf("\nDigite a idade do nadador: ");
    scanf("%d",&idade);

    if((idade >= 5)&&(idade <= 7)){
        printf("\n\nCategoria: Infantil A!\n\n");
    }
    else if((idade >= 8)&&(idade <= 10)){
        printf("\n\nCategoria: Infantil B!\n\n");
    }
    else if((idade >= 11)&&(idade <= 13)){
        printf("\n\nCategoria: Juvenil A!\n\n");
    }
    else if((idade >= 14)&&(idade <= 17)){
        printf("\n\nCategoria: Juvenil B!\n\n");
    }
    else if((idade >= 18)&&(idade <= 25)){
        printf("\n\nCategoria: Senior!\n\n");
    }
    else{
        printf("\n\nIdade fora da faixa etaria!\n\n");
    }
}
