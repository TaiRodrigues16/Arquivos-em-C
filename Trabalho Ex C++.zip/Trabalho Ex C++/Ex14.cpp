#include<stdlib.h>
#include<stdio.h>

// Aluna: Taiane Aparecida Rodrigues      1� Per�odo de SI
/*
14. Escrever um algoritmo que leia dois valores inteiro distintos e informe qual � o maior.
*/

main(){

	int num1, num2;

	printf("Digite o primeiro numero: ");
	scanf("%d",&num1);

	printf("\nDigite o segundo numero: ");
	scanf("%d",&num2);

	if(num1 > num2){
		printf("\n\nO numero %d eh maior que %d ! ",num1,num2);
	}
	else if(num2 > num1){
		printf("\n\nO numero %d eh maior que %d ! ",num2,num1);
	}
	else{
		printf("\n\nOs numeros sao iguais!!!");
	}

}
