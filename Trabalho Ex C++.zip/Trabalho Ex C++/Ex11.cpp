#include<stdlib.h>
#include<stdio.h>

// Aluna: Taiane Aparecida Rodrigues      1� Per�odo de SI
/*
11. Fa�a um algoritmo que receba o pre�o de custo de um produto e mostre o valor de venda. Sabe-se que o pre�o de
custo receber� um acr�scimo de acordo com um percentual informado pelo usu�rio.

*/

main(){

	float precoCust, precoVenda, percent;

	printf("Digite o preco de custo de seu produto: ");
	scanf("%f",&precoCust);

	printf("\nDigite o valor do percentual de acrescimo: ");
	scanf("%f",&percent);

	precoVenda = precoCust + (precoCust * (percent / 100));

	printf("\n\nO valor de venda do produto eh: %.2f \n",precoVenda);

}
