#include<stdlib.h>
#include<stdio.h>

// Aluna: Taiane Aparecida Rodrigues      1� Per�odo de SI
/*
16. Escrever um algoritmo que leia o nome e as tr�s notas obtidas por um aluno durante o semestre. Calcular a sua
m�dia (aritm�tica), informar o nome e sua men��o aprovado (media >= 7), Reprovado (media <= 5) e Recupera��o
(media entre 5.1 a 6.9).
*/

main(){

	char nome[200];
	float nota1,nota2,nota3,media;

	printf("Digite o nome do aluno: ");
	scanf("%s",&nome);

	printf("\nDigite a primeira nota obtida no semestre: ");
	scanf("%f",&nota1);

	printf("\nDigite a segunda nota obtida no semestre: ");
	scanf("%f",&nota2);

	printf("\nDigite a terceira nota obtida no semestre: ");
	scanf("%f",&nota3);

	media = (nota1 + nota2 + nota3) / 3;

	if(media >= 7){
		printf("\n\nO aluno(a) %s foi APROVADO!",&nome);
	}

	if(media <= 5){
		printf("\n\nO aluno(a) %s foi REPROVADO!",&nome);
	}

	if((media > 5.1) && (media < 6.9)){
		printf("\n\nO aluno(a) %s esta de RECUPERACAO!",&nome);
	}
}
