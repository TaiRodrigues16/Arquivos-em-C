#include<stdio.h>
#include<stdlib.h>

// Aluna: Taiane Aparecida Rodrigues      1� Per�odo de SI
/*
28. Escrever um algoritmo para uma empresa que decide dar um reajuste a seus 584 funcion�rios de acordo com os
seguintes crit�rios:
a) 50% para aqueles que ganham menos do que tr�s sal�rios m�nimos;
b) 20% para aqueles que ganham entre tr�s at� dez sal�rios m�nimos;
c) 15% para aqueles que ganham acima de dez at� vinte sal�rios m�nimos;
d) 10% para os demais funcion�rios.
Leia o nome do funcion�rio, seu sal�rio e o valor do sal�rio m�nimo. Calcule o seu novo sal�rio reajustado. Escrever o
nome do funcion�rio, o reajuste e seu novo sal�rio. Calcule quanto � empresa vai aumentar sua folha de pagamento.

*/

main(){

    float salario, salMim,reajuste,salFinal,antesSal,depoisSal;
    char nome[50];
    int i;

    antesSal = salario;
    depoisSal = salFinal;

    printf("\nDigite o valor do salario minimo: ");
    scanf("%f",&salMim);

    for(i=0;i<584;i++){
        printf("\n\nDigite o nome do funcionario: ");
        scanf("%s",&nome);
        printf("\nDigite o seu salario: ");
        scanf("%f",&salario);

        antesSal = antesSal + salario;

        if(salario < (salMim * 3)){
            reajuste = salario * 0.50;
            salFinal = salario + reajuste;
            printf("\nO funcionario: %s",&nome);
            printf("\nSeu novo salario: %.2f",salFinal);
            printf("\nSeu reajuste foi de: %.2f",reajuste);
        }
        else if((salario >= (salMim * 3))&&(salario <= (salMim * 10))){
            reajuste = salario * 0.20;
            salFinal = salario + reajuste;
            printf("\nO funcionario: %s",&nome);
            printf("\nSeu novo salario: %.2f",salFinal);
            printf("\nSeu reajuste foi de: %.2f",reajuste);
        }
        else if((salario > (salMim * 10))&&(salario <= (salMim * 20))){
            reajuste = salario * 0.15;
            salFinal = salario + reajuste;
            printf("\nO funcionario: %s",&nome);
            printf("\nSeu novo salario: %.2f",salFinal);
            printf("\nSeu reajuste foi de: %.2f",reajuste);
        }
        else{
            reajuste = salario * 0.10;
            salFinal = salario + reajuste;
            printf("\nO funcionario: %s",&nome);
            printf("\nSeu novo salario: %.2f",salFinal);
            printf("\nSeu reajuste foi de: %.2f",reajuste);
        }

        depoisSal = depoisSal + salFinal;
    }

    printf("\n\nA empresa aumentara em sua folha de pagamento: %.2f reais. \n",depoisSal - antesSal);

}
