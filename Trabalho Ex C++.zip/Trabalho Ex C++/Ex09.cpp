#include<stdlib.h>
#include<stdio.h>

// Aluna: Taiane Aparecida Rodrigues      1� Per�odo de SI
/*
9. Fa�a um algoritmo que receba um valor que foi depositado e exiba o valor com rendimento ap�s um m�s.
 Considere fixo o juro da poupan�a em 0,70% a. m.
  mensais = 0,058 ou aproximadamente 0,06
*/

main(){
	float valorDep, valorRend;

	printf("Digite o valor depositado: ");
	scanf("%f",&valorDep);

	valorRend = valorDep + (valorDep * 0.058);

	printf("\n\nO valor com o rendimento eh de: %.2f",valorRend);

}
