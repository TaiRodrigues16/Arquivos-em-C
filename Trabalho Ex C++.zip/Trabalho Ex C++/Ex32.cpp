#include<stdio.h>
#include<stdlib.h>

// Aluna: Taiane Aparecida Rodrigues      1� Per�odo de SI
/*
32. Dados tr�s valores A, B e C, em que A e B s�o n�meros reais e C � um caractere, pede-se para imprimir o resultado
da opera��o de A por B se C for um s�mbolo de operador aritm�tico; caso contr�rio deve ser impressa uma
mensagem de operador n�o definido. Tratar erro de divis�o por zero.

*/

main(){

    float A,B,soma,sub,divi,mult;
    char C;

    printf("\nDigite o primeiro numero: ");
    scanf("%f",&A);
    printf("\nDigite o segundo numero: ");
    scanf("%f",&B);
    printf("\n\nDigite o operador aritmetico: ");
    printf("\n + -> Somar");
    printf("\n - -> Subtrair");
    printf("\n * -> Multiplicar");
    printf("\n / -> Dividir\n");
    scanf("%s",&C);

    if(C == '+'){
        soma = A + B;
        printf("\n\nO resultado eh: %.2f\n\n",soma);
    }
    else if(C == '-'){
        sub = A - B;
        printf("\n\nO resultado eh: %.2f\n\n",sub);
    }
    else if(C == '*'){
        mult = A * B;
        printf("\n\nO resultado eh: %.2f\n\n",mult);
    }
    else if(C == '/'){
        if(B == 0){
           printf("\n\nNao ha divisao por zero!\n\n");
        }else{
           divi = A / B;
           printf("\n\nO resultado eh: %.2f\n\n",divi);
        }
    }
    else{
       printf("\n\nOperador nao definido!\n\n");
    }
}
