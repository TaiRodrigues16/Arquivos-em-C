#include<stdlib.h>
#include<stdio.h>

// Aluna: Taiane Aparecida Rodrigues      1� Per�odo de SI
/*
15. Fa�a um algoritmo que receba um n�mero e diga se este n�mero est� no intervalo entre 100 e 200.
*/

main(){

	float num;

	printf("Digite um numero: ");
	scanf("%f",&num);

	if((num > 100)&&(num < 200)){
		printf("\nEste numero esta no intervalo entre 100 e 200!");
	}else{
		printf("\nEste numero nao esta no intervalo!");
	}

}
