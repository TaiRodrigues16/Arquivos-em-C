#include<stdio.h>
#include<stdlib.h>

// Aluna: Taiane Aparecida Rodrigues      1� Per�odo de SI
/*
18. Fa�a um algoritmo que receba a idade de 75 pessoas e mostre mensagem informando "maior de idade" e "menor de
idade" para cada pessoa. Considere a idade a partir de 18 anos como maior de idade.

*/

main(){

	int idade,i;

	for(i=0;i < 75;i++){
		printf("\nDigite a idade da pessoa: ");
		scanf("%d",&idade);

		if(idade >= 18){
			printf("\nEssa pessoa eh MAIOR de idade!\n\n");
		}else{
			printf("\nEssa pessoa eh MENOR de idade!\n\n");
		}
	}

}
