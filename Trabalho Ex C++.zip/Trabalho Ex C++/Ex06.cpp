#include<stdio.h>
#include<stdlib.h>

// Aluna: Taiane Aparecida Rodrigues      1� Per�odo de SI
/*
6. Ler dois valores para as vari�veis A e B, e efetuar as trocas dos valores de forma que a vari�vel A passe a possuir o
valor da vari�vel B e a vari�vel B passe a possuir o valor da vari�vel A. Apresentar os valores trocados.

*/

main(){
	float varA, varB, varC;

	varC = 0;

	printf("Digite o valor da variavel A: ");
	scanf("%f",&varA);
	printf("Digite o valor da variavel B: ");
	scanf("%f",&varB);

	varC = varA;
	varA = varB;
	varB = varC;

	printf("\n\nOs valores trocados: ");
	printf("\nVariavel A: %.2f",varA);
	printf("\nVariavel B: %.2f",varB);

}
