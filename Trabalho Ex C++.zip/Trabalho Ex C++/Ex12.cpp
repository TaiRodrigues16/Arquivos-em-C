#include<stdlib.h>
#include<stdio.h>

// Aluna: Taiane Aparecida Rodrigues      1� Per�odo de SI
/*
12. O custo ao consumidor de um carro novo � a soma do custo de f�brica com a percentagem do distribuidor e dos
impostos (aplicados, primeiro os impostos sobre o custo de f�brica, e depois a percentagem do distribuidor sobre o
resultado). Supondo que a percentagem do distribuidor seja de 28% e os impostos 45%. Escrever um algoritmo que
leia o custo de f�brica de um carro e informe o custo ao consumidor do mesmo.
	custoCons = custoFab + (0.45 * custoFab) + ((custoFab + (0.45 * custoFab)) * 0.28);4500
*/

main(){

	float custoFab, custoCons;

	printf("Digite o custo de fabrica de um carro: ");
	scanf("%f",&custoFab);

	custoCons = custoFab + (0.45 * custoFab) + ((custoFab + (0.45 * custoFab)) * 0.28);

	printf("\n\nO preco de custo ao consumidor eh: %.2f",custoCons);

}
