#include<stdio.h>
#include<stdlib.h>

// Aluna: Taiane Aparecida Rodrigues      1� Per�odo de SI
/*
26. Fa�a um algoritmo que leia um n�mero de 1 a 5 e escreva por extenso. Caso o usu�rio digite um n�mero que n�o
esteja neste intervalo, exibir mensagem: n�mero inv�lido.

*/

main(){
    int num;

    printf("\nDigite um numero: ");
    scanf("%d",&num);

    if(num == 1){
        printf("\nNumero: Um\n");
    }
    else if(num == 2){
        printf("\nNumero: Dois\n");
    }
    else if(num == 3){
        printf("\nNumero: Tres\n");
    }
    else if(num == 4){
        printf("\nNumero: Quatro\n");
    }
    else if(num == 5){
        printf("\nNumero: Cinco\n");
    }else{
        printf("\nNumero Invalido!\n");
    }
}
