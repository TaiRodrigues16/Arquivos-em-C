#include<stdio.h>
#include<stdlib.h>

// Aluna: Taiane Aparecida Rodrigues      1� Per�odo de SI
/*
24. Fa�a um algoritmo que receba �N� n�meros e mostre positivo, negativo ou zero para cada n�mero.
*/

main(){
    int num,qtd,i;

    printf("Quantos numeros voce deseja testar? ");
    scanf("%d",&qtd);

    for(i=0;i<qtd;i++){
        printf("\n\nDigite um numero: ");
        scanf("%d",&num);

        if(num > 0){
            printf("\nEste numero eh positivo!");
        }
        if(num < 0){
            printf("\nEste numero eh negativo!");
        }
        if(num == 0){
            printf("\nEste numero eh igual a 0!");
        }
    }
}
