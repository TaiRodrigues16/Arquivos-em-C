#include<stdio.h>
#include<stdlib.h>

// Aluna: Taiane Aparecida Rodrigues      1� Per�odo de SI
/*
7. Ler uma temperatura em graus Celsius e apresent�-la convertida em graus Fahrenheit. A f�rmula de convers�o �:
F=(9*C+160) / 5, sendo F a temperatura em Fahrenheit e C a temperatura em Celsius.

*/

main(){

	float temp,F;

	printf("Digite a temperatura em Celsius: ");
	scanf("%f",&temp);

	F = (9 * temp + 160) / 5;

	printf("\n\nA temperatura em Fahrenheit eh: %.2f F",F);

}
