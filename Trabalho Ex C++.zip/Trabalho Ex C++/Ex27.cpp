#include<stdio.h>
#include<stdlib.h>

// Aluna: Taiane Aparecida Rodrigues      1� Per�odo de SI
/*
27. A concession�ria de ve�culos �CARANGO� est� vendendo os seus ve�culos com desconto. Fa�a um algoritmo que
calcule e exiba o valor do desconto e o valor a ser pago pelo cliente. O desconto dever� ser calculado sobre o valor
do ve�culo de acordo com o combust�vel (�lcool � 25%, gasolina � 21% ou diesel �14%). Com valor do ve�culo zero
encerra entrada de dados. Informe total de desconto e total pago pelos clientes.

*/

main(){
    float valorDesc, valorClient,valorVeic,somaDesc,somaClient;
    char combus;

    somaDesc = valorDesc;
    somaClient = valorClient;

    do{
        printf("\nDigite o valor do veiculo: ");
        scanf("%f",&valorVeic);
        printf("\nQual o tipo de combustivel? ");
        printf("\nA -> Alcool");
        printf("\nG -> Gaslina");
        printf("\nD -> Diesel\n");
        scanf("%s",&combus);

        if((combus == 'A')||(combus == 'a')){
            valorDesc = valorVeic * 0.25;
            valorClient = valorVeic - valorDesc;
            printf("\nO valor do desconto sera de: %.2f\n",valorDesc);
            printf("\nO valor a ser pago pelo cliente sera de: %.2f",valorClient);
        }
        else if((combus == 'G')||(combus == 'g')){
            valorDesc = valorVeic * 0.21;
            valorClient = valorVeic - valorDesc;
            printf("\nO valor do desconto sera de: %.2f\n",valorDesc);
            printf("\nO valor a ser pago pelo cliente sera de: %.2f",valorClient);
        }
        else if((combus == 'D')||(combus == 'd')){
            valorDesc = valorVeic * 0.14;
            valorClient = valorVeic - valorDesc;
            printf("\nO valor do desconto sera de: %.2f\n",valorDesc);
            printf("\nO valor a ser pago pelo cliente sera de: %.2f",valorClient);
        }

        somaDesc = somaDesc + valorDesc;
        somaClient = somaClient + valorClient;

    }while(valorVeic != 0);

    printf("\n\nO total de descontos eh: %.2f",somaDesc);
    printf("\n\nO total pago pelos clientes eh: %.2f\n\n",somaClient);

}
