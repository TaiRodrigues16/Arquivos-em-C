#include<stdio.h>
#include<stdlib.h>

// Aluna: Taiane Aparecida Rodrigues      1� Per�odo de SI
/*
1. Fa�a um algoritmo que receba dois n�meros e exiba o resultado da sua soma.
*/

main(){

	float num1,num2, result;

	printf("Digite o primeiro numero: \n");
	scanf("%f",&num1);
	printf("Digite o segundo numero: \n\n");
	scanf("%f",&num2);

	result = num1 + num2;

	printf("\n\nO resultado da soma eh: %.2f",result);

}
