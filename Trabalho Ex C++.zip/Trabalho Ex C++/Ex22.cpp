#include<stdio.h>
#include<stdlib.h>

// Aluna: Taiane Aparecida Rodrigues      1� Per�odo de SI
/*
22. Fa�a um algoritmo que receba o pre�o de custo e o pre�o de venda de 40 produtos. Mostre como resultado se
houve lucro, preju�zo ou empate para cada produto. Informe media de pre�o de custo e do pre�o de venda.
*/

main(){
    float precoCusto, precoVenda,soma1,soma;
    int i;

    soma1 = precoCusto;
    soma = precoVenda;

    for(i=0;i<40;i++){
        printf("\nDigite o preco de custo do produto: ");
        scanf("%f",&precoCusto);
        printf("\nDigite o preco de venda: ");
        scanf("%f",&precoVenda);

        if(precoCusto < precoVenda){
            printf("\nHouve lucro!\n");
            soma1 = soma1 + precoCusto;
            soma = soma + precoVenda;
        }
        if(precoCusto == precoVenda){
            printf("\nHouve empate!\n");
            soma1 = soma1 + precoCusto;
            soma = soma + precoVenda;
        }
        if(precoCusto > precoVenda){
            printf("\nHouve prejuizo!\n");
            soma1 = soma1 + precoCusto;
            soma = soma + precoVenda;
        }

    }

    printf("\n\nA media de Preco de Custo eh: %.2f",soma1/40);
    printf("\n\nA media de Preco de Venda eh: %.2f",soma/40);
}
