#include<stdio.h>
#include<stdlib.h>

// Aluna: Taiane Aparecida Rodrigues      1� Per�odo de SI
/*
3. Escrever um algoritmo para determinar o consumo m�dio de um autom�vel sendo
fornecida a dist�ncia total percorrida pelo autom�vel e o total de combust�vel gasto.
	consumo medio = distancia / combustivel gasto       ..... km/l
*/

main(){

	float dist, combus, consumo;

	printf("Digite a distancia percorrida em quilometros: ");
	scanf("%f",&dist);
	printf("\nDigite a quantidade de combustivel utilizada em litros: ");
	scanf("%f",&combus);

	consumo = dist / combus;

	printf("\n\nO consumo medio eh: %.2f km/l",consumo);



}
