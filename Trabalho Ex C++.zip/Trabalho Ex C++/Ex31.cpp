#include<stdio.h>
#include<stdlib.h>

// Aluna: Taiane Aparecida Rodrigues      1� Per�odo de SI
/*
31. Escrever um algoritmo que leia tr�s valores inteiros distintos e os escreva em ordem crescente.
*/

main(){

    int num1,num2,num3;

    printf("\nDigite o primeiro numero: ");
    scanf("%d",&num1);
    printf("\nDigite o segundo numero: ");
    scanf("%d",&num2);
    printf("\nDigite o terceiro numero: ");
    scanf("%d",&num3);

    if((num1 < num2)&&(num1 < num3)){
       if(num2 < num3){
            printf("\n\nA ordem crescente fica: ");
            printf("\n -> %d",num1);
            printf("\n -> %d",num2);
            printf("\n -> %d",num3);
       }
       else if(num2 > num3){
            printf("\n\nA ordem crescente fica: ");
            printf("\n -> %d",num1);
            printf("\n -> %d",num3);
            printf("\n -> %d",num2);
       }
    }
    if((num2 < num1)&&(num2 < num3)){
       if(num1 > num3){
            printf("\n\nA ordem crescente fica: ");
            printf("\n -> %d",num2);
            printf("\n -> %d",num3);
            printf("\n -> %d",num1);
       }
       else if(num3 > num1){
            printf("\n\nA ordem crescente fica: ");
            printf("\n -> %d",num2);
            printf("\n -> %d",num1);
            printf("\n -> %d",num3);
       }
    }
    if((num3 < num1)&&(num3 < num2)){
       if(num1 < num2){
            printf("\n\nA ordem crescente fica: ");
            printf("\n -> %d",num3);
            printf("\n -> %d",num1);
            printf("\n -> %d",num2);
       }
       else if(num1 > num2){
            printf("\n\nA ordem crescente fica: ");
            printf("\n -> %d",num3);
            printf("\n -> %d",num2);
            printf("\n -> %d",num1);
       }
    }
}
