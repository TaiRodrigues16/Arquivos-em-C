#include<stdio.h>
#include<stdlib.h>

// Aluna: Taiane Aparecida Rodrigues      1� Per�odo de SI
/*
25. Fa�a um algoritmo que leia dois n�meros e identifique se s�o iguais ou diferentes. Caso eles sejam iguais imprima
uma mensagem dizendo que eles s�o iguais. Caso sejam diferentes, informe qual n�mero � o maior, e uma
mensagem que s�o diferentes.

*/

main(){

    int num1,num2;

    printf("Digite o primeiro numero: ");
    scanf("%d",&num1);
    printf("\nDigite o segundo numero: ");
    scanf("%d",&num2);

    if(num1 == num2){
        printf("\nEstes numeros sao iguais!\n");
    }else{
        printf("\nEstes numeros sao diferentes!\n");

        if(num1 > num2){
           printf("\nO numero %d eh maior!\n",num1);
        }
        if(num1 < num2){
           printf("\nO numero %d eh maior!\n",num2);
        }
    }
}
