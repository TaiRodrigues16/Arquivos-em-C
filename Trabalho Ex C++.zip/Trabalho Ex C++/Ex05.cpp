#include<stdio.h>
#include<stdlib.h>

// Aluna: Taiane Aparecida Rodrigues      1� Per�odo de SI
/*
5. Escrever um algoritmo que leia o nome de um aluno e as notas das tr�s provas que ele obteve no semestre. No final
informar o nome do aluno e a sua m�dia (aritm�tica).

*/

main(){
	char nome[200];
	float nota1,nota2,nota3,media;

	printf("Digite o nome do aluno: ");
	scanf("%s",&nome);
	printf("\nDigite a nota da primeira prova: ");
	scanf("%f",&nota1);
	printf("Digite a nota da segunda prova: ");
	scanf("%f",&nota2);
	printf("Digite a nota da terceira prova: ");
	scanf("%f",&nota3);

	media = (nota1 + nota2 + nota3)/3;

	printf("\n\nO nome do aluno eh: %s",nome);
	printf("\nA sua media eh de: %.2f",media);
}
