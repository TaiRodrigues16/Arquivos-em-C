#include<stdio.h>
#include<stdlib.h>

// Aluna: Taiane Aparecida Rodrigues      1� Per�odo de SI
/*
23. Fa�a um algoritmo que receba um n�mero e mostre uma mensagem caso este n�mero sege maior que 80, menor
que 25 ou igual a 40.

*/
main(){
    int num;

    printf("Digite um numero: ");
    scanf("%d",&num);

    if(num > 80){
        printf("\nEste numero eh maior que 80!\n");
    }
    if(num < 25){
        printf("\nEste numero eh menor que 25!\n");
    }
    if(num == 40){
        printf("\nEste numero eh igual a 40!\n");
    }
}
