#include<stdio.h>
#include<stdlib.h>

// Aluna: Taiane Aparecida Rodrigues      1� Per�odo de SI
/*
8. Elaborar um algoritmo que efetue a apresenta��o do valor da convers�o em real (R$) de um valor lido em d�lar
(US$). O algoritmo dever� solicitar o valor da cota��o do d�lar e tamb�m a quantidade de d�lares dispon�veis com o
usu�rio.
		valor dolar = R$3.1230
*/

main(){

	float real, dolar, conv, dolarDisp;

	printf("Digite um valor em dolar: ");
	scanf("%f",&dolar);
	printf("Digite o valor da cotacao do dolar em real: ");
	scanf("%f",&real);

	conv = dolar * real;

	dolarDisp = conv / dolar;

	printf("A conversao eh: %.2f",conv);
	printf("A quantidade de dolares disponivel: %.2f",dolarDisp);

}
