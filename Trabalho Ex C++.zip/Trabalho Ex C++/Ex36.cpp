#include<stdio.h>
#include<stdlib.h>

// Aluna: Taiane Aparecida Rodrigues      1� Per�odo de SI
/*
36. Fa�a um algoritmo que calcule o valor da conta de luz de uma pessoa. Sabe-se que o c�lculo da conta de luz segue
a tabela abaixo:
Tipo de Cliente Valor do KW/h
1 (Resid�ncia) 0,60
2 (Com�rcio) 0,48
3 (Ind�stria) 1,29

*/

main(){

    int tipoDeResidencia,qtd;
    float conta;

    printf("\nQual eh o tipo de residencia: ");
    printf("\n1 -> Residencia");
    printf("\n2 -> Comercio");
    printf("\n3 -> Industria\n");
    scanf("%d",&tipoDeResidencia);

    if(tipoDeResidencia == 1){
        printf("\n\nQual a quantidade de KW/h foram gastos? ");
        scanf("%d",&qtd);
        conta = qtd * 0.60;
        printf("\n\nO valor da conta de energia sera: %.2f reais.\n\n",conta);
    }
    else if(tipoDeResidencia == 2){
        printf("\n\nQual a quantidade de KW/h foram gastos? ");
        scanf("%d",&qtd);
        conta = qtd * 0.48;
        printf("\n\nO valor da conta de energia sera: %.2f reais.\n\n",conta);
    }
    else if(tipoDeResidencia == 3){
        printf("\n\nQual a quantidade de KW/h foram gastos? ");
        scanf("%d",&qtd);
        conta = qtd * 1.29;
        printf("\n\nO valor da conta de energia sera: %.2f reais.\n\n",conta);
    }
    else{
        printf("\n\nEntrada de dados incorreta!\n\n");
    }
}
