#include<stdlib.h>
#include<stdio.h>

// Aluna: Taiane Aparecida Rodrigues      1� Per�odo de SI
/*
20. A concession�ria de ve�culos "CARANGO VELHO" est� vendendo os seus ve�culos com desconto. Fa�a um
algoritmo que calcule e exiba o valor do desconto e o valor a ser pago pelo cliente de v�rios carros. O desconto
dever� ser calculado de acordo com o ano do ve�culo. At� 2000 - 12% e acima de 2000 - 7%. O sistema dever�
perguntar se deseja continuar calculando desconto at� que a resposta seja: "(N) N�o" . Informar total de carros com
ano at� 2000 e total geral.

*/

main(){
	float valorCar, valorDes, valorTotal;
	int anoCar,cont1,cont2;
	char resp;

	cont1 = 0;
	cont2 = 0;

	resp = 's';

	while(resp != 'n'){
		printf("Entre com o valor do carro: ");
		scanf("%f",&valorCar);

		printf("\nEntre com o ano do carro: ");
		scanf("%d",&anoCar);

		if(anoCar <= 2000){
			valorDes = (valorCar * 0.12);
			valorTotal = valorCar - valorDes;
			cont1 = cont1 + 1;
		}
		else{
			valorDes = (valorCar * 0.07);
			valorTotal = valorCar - valorDes;
			cont2 = cont2 + 1;

		}

		printf("\nO valor do desconto eh: %.2f\n",valorDes);
		printf("\nO valor a ser pago pelo cliente eh: %.2f\n",valorTotal);
		printf("\nDeseja continuar calculando o valor dos carros? \n");
		printf("\n's' -> Sim\n");
		printf("\n'n' -> Nao\n");
		scanf("%s",&resp);
	}

	printf("\nO total de carros ate o ano 2000 sao: %d\n",cont1);
	printf("\nO total de carros no geral sao: %d\n",cont1+cont2);

}
