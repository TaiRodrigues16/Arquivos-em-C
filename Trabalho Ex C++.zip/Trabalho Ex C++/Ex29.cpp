#include<stdio.h>
#include<stdlib.h>

// Aluna: Taiane Aparecida Rodrigues      1� Per�odo de SI
/*
29. Fa�a um algoritmo que receba o n�mero do m�s e mostre o m�s correspondente. Valide m�s inv�lido.
*/

main(){

    int num;

    printf("Digite um numero referente a um mes: ");
    scanf("%d",&num);

    if(num == 1){
        printf("\n\nMes: Janeiro\n\n");
    }
    else if(num == 2){
        printf("\n\nMes: Fevereiro\n\n");
    }
    else if(num == 3){
        printf("\n\nMes: Marco\n\n");
    }
    else if(num == 4){
        printf("\n\nMes: Abril\n\n");
    }
    else if(num == 5){
        printf("\n\nMes: Maio\n\n");
    }
    else if(num == 6){
        printf("\n\nMes: Junho\n\n");
    }
    else if(num == 7){
        printf("\n\nMes: Julho\n\n");
    }
    else if(num == 8){
        printf("\n\nMes: Agosto\n\n");
    }
    else if(num == 9){
        printf("\n\nMes: Setembro\n\n");
    }
    else if(num == 10){
        printf("\n\nMes: Outubro\n\n");
    }
    else if(num == 11){
        printf("\n\nMes: Novembro\n\n");
    }
    else if(num == 12){
        printf("\n\nMes: Dezembro\n\n");
    }
    else{
       printf("\n\nMes Invalido!\n\n");
    }
}
