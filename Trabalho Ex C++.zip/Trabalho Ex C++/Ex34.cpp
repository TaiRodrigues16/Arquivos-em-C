#include<stdio.h>
#include<stdlib.h>

// Aluna: Taiane Aparecida Rodrigues      1� Per�odo de SI
/*
34. A escola �APRENDER� faz o pagamento de seus professores por hora/aula. Fa�a um algoritmo que calcule e exiba o
sal�rio de um professor. Sabe-se que o valor da hora/aula segue a tabela abaixo:
Professor N�vel 1 R$12,00 por hora/aula
Professor N�vel 2 R$17,00 por hora/aula
Professor N�vel 3 R$25,00 por hora/aula

*/

main(){

    int nivel, qtd;
    float salario;

    printf("\nDigite a quantidade de aulas do professor: ");
    scanf("%d",&qtd);
    printf("\nQual eh o nivel do professor: ");
    printf("\n 1 -> Professor Nivel 1");
    printf("\n 2 -> Professor Nivel 2");
    printf("\n 3 -> Professor Nivel 3\n");
    scanf("%d",&nivel);

    if(nivel == 1){
        salario = qtd * 12;
        printf("\n\nO salario do professor sera: %.2f reais.\n\n",salario);
    }
    else if(nivel == 2){
        salario = qtd * 17;
        printf("\n\nO salario do professor sera: %.2f reais.\n\n",salario);
    }
    else if(nivel == 3){
        salario = qtd * 25;
        printf("\n\nO salario do professor sera: %.2f reais.\n\n",salario);
    }
    else{
        printf("\n\nEntrada de dados incorreta!\n\n");
    }
}
