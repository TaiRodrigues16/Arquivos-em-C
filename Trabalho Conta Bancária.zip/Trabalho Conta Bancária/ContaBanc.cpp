#include<stdio.h>

// Trabalho Conta Matriz
// Alunos: Gilberto Henrique / Taiane Rodrigues

int main(){

    int MatrizBanco[5][2],i,j,opc=0,conta,deposito,saque,soma=0;

    for(i=0;i<5;i++){
        for(j=0;j<2;j++){
            if(j==0){
                printf("Digite um numero para conta: ");
                scanf("%d",&MatrizBanco[i][j]);
            }else{
                printf("Digite o saldo inicial: ");
                scanf("%d",&MatrizBanco[i][j]);
            }
        }
    }

    do{
        printf("\n\n1 - Efetuar um deposito em uma conta");
        printf("\n2 - Efetuar um saque de uma conta");
        printf("\n3 - Consultar o saldo de uma conta");
        printf("\n4 - Consultar o saldo geral");
        printf("\n5 - Finalizar Programa");
        printf("\n\nDigite uma opcao: ");
        scanf("%d",&opc);

        if(opc == 1){
            printf("\nDigite o numero da conta: ");
            scanf("%d",&conta);
            printf("Digite o valor do deposito: ");
            scanf("%d",&deposito);

            for(i=0;i<5;i++){
                for(j=0;j<2;j++){
                   if(j==0){
                        if(conta == MatrizBanco[i][j]){
                            printf("\nDeposito feito!");
                            MatrizBanco[i][j=1] += deposito;
                        }else{
                            if(i==4){
                                printf("\nConta inexistente!");
                            }
                        }
                    }
                }
            }
        }

        else if(opc == 2){
            printf("\nDigite o numero da conta: ");
            scanf("%d",&conta);
            printf("Digite o valor do saque: ");
            scanf("%d",&saque);

            for(i=0;i<5;i++){
                for(j=0;j<2;j++){
                   if(j==0){
                        if(conta == MatrizBanco[i][j]){
                            if(saque <= MatrizBanco[i][j=1]){
                                printf("\nSaque feito!");
                                MatrizBanco[i][j=1] -= saque;
                            }else{
                                printf("Saldo Insuficiente!");
                            }
                        }else{
                            if(i==4){
                                printf("\nConta inexistente!");
                            }
                        }
                    }
                }
            }
        }

        else if(opc == 3){
            printf("\nDigite o numero da conta: ");
            scanf("%d",&conta);

            for(i=0;i<5;i++){
                for(j=0;j<2;j++){
                    if(j==0){
                        if(conta == MatrizBanco[i][j]){
                            printf("\nO saldo eh de: %d",MatrizBanco[i][j=1]);
                        }else{
                            if(i==4){
                                printf("\nConta inexistente!");
                            }
                        }
                    }
                }
            }
        }

        else if(opc == 4){
            printf("\nSaldo total: ");
            for(i=0;i<5;i++){
                for(j=0;j<2;j++){
                    if(j==1){
                        soma += MatrizBanco[i][j];
                    }
                }
            }
            printf("%d \n",soma);
        }

    }while(opc!=5);

    return 0;
}
