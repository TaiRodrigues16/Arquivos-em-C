#include<stdio.h>

//Aluna: Taiane Aparecida Rodrigues  2� Periodo de SI

/*1) Fa�a um programa que possua um vetor de 10 n�meros inteiros.
Calcule a soma dos n�meros no vetor, ap�s terem sidos digitados por um usu�rio. */

int main(){

	int i,num[10],soma=0;

	for(i=0;i<10;i++){
		printf("Digite um numero: ");
		scanf("%d",&num[i]);
		soma += num[i];
	}

	printf("\nA soma eh: %d\n",soma);

	return 0;
}
