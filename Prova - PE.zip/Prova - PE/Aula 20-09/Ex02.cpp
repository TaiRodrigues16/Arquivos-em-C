#include<stdio.h>

//Aluna: Taiane Aparecida Rodrigues  2� Periodo de SI

/*2) Fa�a um programa que tenha tr�s vetores. Nos dois primeiros, leia 7 n�meros reais e
no outro calcule, nas mesmas posi��es de �ndices, a soma dos n�meros do vetor 1 e 2. Exemplo:
1. Vet1 : [2,3,0....]
2. Vet2 : [9,-8,2,...]
3. Vet3 : [11,-5,2,...] */

int main()
{
	int i,j,k,l;
	float vet1[7],vet2[7],vet3[7];

	for(i=0;i<7;i++){
		printf("Digite um numero no vet1: ");
		scanf("%f",&vet1[i]);
		printf("Digite um numero no vet2: ");
		scanf("%f",&vet2[i]);
		vet3[i] = vet1[i] + vet2[i];
	}

	printf("\nVet1 :");
	for(j=0;j<7;j++){
		printf(" %.2f,",vet1[j]);
	}

	printf("\nVet2 :");
	for(k=0;k<7;k++){
		printf(" %.2f,",vet2[k]);
	}

	printf("\nVet3 :");
	for(l=0;l<7;l++){
		printf(" %.2f,",vet3[l]);
	}

    return 0;
}
