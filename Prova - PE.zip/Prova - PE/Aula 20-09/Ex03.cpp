#include<stdio.h>

//Aluna: Taiane Aparecida Rodrigues  2� Periodo de SI

/* 3) Fa�a um programa que leia uma string de 10 caracteres. Depois da leitura, mostrar a
string ao contr�rio, por exemplo
1. String lida: Estudando!
2. Resultado: !odnadutsE */

int main(){

    char caracteres[10];
    int i;

    printf("Digite alguma coisa: ");
    scanf("%s",&caracteres);
    printf("\nString Lida: %s",caracteres);
    printf("\n\nResultado: \n");

    for(i=10;i>=0;i--){
        printf("%c",caracteres[i]);
    }
    printf("\n");
    return 0;
}
