#include<stdio.h>
#include<string.h>

//Aluna: Taiane Aparecida Rodrigues  2� Periodo de SI

/* 5) Fa�a um programa em C que receba uma frase, inverta a frase letra a letra,
da �ltima para a primeira, e mostre esta frase ao final. */

int main(){

    char frase[50];
    int i, tam;

    printf("Digite uma frase: ");
    gets(frase);
    printf("\n");

    tam = strlen(frase);

    for(i=tam;i>=0;i--){
        if(frase[i]!='\0'){
            if(frase[i]==' '){
                frase[i] = ' ';
            }
            printf("%c",frase[i]);
        }
    }

    printf("\n");
    return 0;
}
