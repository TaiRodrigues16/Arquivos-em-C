#include<stdio.h>
#include<string.h>

//Aluna: Taiane Aparecida Rodrigues  2� Periodo de SI

/* 4) Fa�a um programa em C que receba uma frase do usu�rio e mostre a frase,
palavra por palavra, uma em cada linha diferente. */

int main(){

    char frase[50];
    int i;

    printf("Digite uma frase: ");
    gets(frase);

    printf("\n");
    for(i=0;frase[i]!='\0';i++){
        if(frase[i] == ' '){
            frase[i] = '\n';
        }
    }

    puts(frase);

    return 0;
}
