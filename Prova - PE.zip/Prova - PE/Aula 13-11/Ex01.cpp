#include<stdio.h>
#include<string.h>

//Aluna: Taiane Aparecida Rodrigues  2� Periodo de SI

/* 1) Fa�a um programa em C que receba uma frase qualquer fornecida pelo
usu�rio, calcule e mostre quantas palavras a frase possui. */

int main(){

    char frase[50];
    int i, cont=0;

    printf("Digite uma frase: ");
    gets(frase);

    for(i=0;frase[i]!='\0';i++){
        if(frase[i] == ' '){
            cont++;
        }
    }

    printf("\nEsta frase tem %d palavras! \n",cont+1);

    return 0;
}
