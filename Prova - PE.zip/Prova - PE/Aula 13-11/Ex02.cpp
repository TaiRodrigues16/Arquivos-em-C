#include<stdio.h>
#include<string.h>

//Aluna: Taiane Aparecida Rodrigues  2� Periodo de SI

/*2) Fa�a um programa em C que receba uma frase e troque as vogais existentes
nesta frase por um asterisco (*). Por exemplo: Frase �EU ESTOU NA
ESCOLA� resultado na tela �** *ST** N* *SC*L*� */

int main(){

    char frase[50];
    int i;

    printf("Digite uma frase: ");
    gets(frase);

    for(i=0;frase[i]!='\0';i++){
        if(((frase[i] == 'a')||(frase[i] == 'A'))||((frase[i] == 'e')||(frase[i] == 'E'))||((frase[i] == 'i')||(frase[i] == 'I'))||((frase[i] == 'o')||(frase[i] == 'O'))||((frase[i] == 'u')||(frase[i] == 'U'))){
            frase[i] = '*';
        }
    }

    puts(frase);

    return 0;
}
