#include<stdio.h>
#include<string.h>

//Aluna: Taiane Aparecida Rodrigues  2� Periodo de SI

/* 3) Fa�a um programa em C que se comporte como um v�rus. Este programa ir�
duplicar as palavras digitadas em uma frase. */

int main(){

    char frase[100],copia[100],palavra[100];
    int i, tam, cont=0;

    printf("Digite uma frase: ");
    gets(frase);

    tam = strlen(frase);

    strcpy(copia,"\0"); // Inicializando a variavel
    for(i=0;i<=tam;i++){
        if((frase[i] != ' ') && (frase[i] != '\0')){
            palavra[cont] = frase[i];
            cont++;
        }
        else{
            palavra[cont] = '\0';
            cont=0; //Duplica a palavra na frase nova
            strcat(copia, palavra);
            strcat(copia," ");
            strcat(copia, palavra);
            strcat(copia," ");
        }
    }
    strcat(copia,"\0");
    puts(copia);

    return 0;
}
