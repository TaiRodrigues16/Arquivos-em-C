#include<stdio.h>

//Aluna: Taiane Aparecida Rodrigues  2� Periodo de SI

/* 2 Dada um matriz bidimensional contendo 4 notas de 10 alunos, elaborar um
programa que calcule e exiba uma outra matriz unidimensional ( um vetor) que dever�
conter a m�dia aritm�tica das 4 notas de cada aluno. */

int main(){

    int i,j;
    float matriz[10][4],media[10],soma=0,soma1=0,soma2=0,soma3=0,soma4=0,soma5=0,soma6=0,soma7=0,soma8=0,soma9=0;

    for(i=0;i<10;i++){
        for(j=0;j<4;j++){
            printf("Digite a nota: ");
            scanf("%f",&matriz[i][j]);
        }
    }

    for(i=0;i<10;i++){
        for(j=0;j<4;j++){
            if(i==0){
                soma1 += matriz[i][j];
                media[i=0] = soma1 / 4;
            }
            else if(i==1){
                soma2 += matriz[i][j];
                media[i=1] = soma2 / 4;
            }
            else if(i==2){
                soma3 += matriz[i][j];
                media[i=2] = soma3 / 4;
            }
            else if(i==3){
                soma4 += matriz[i][j];
                media[i=3] = soma4 / 4;
            }
            else if(i==4){
                soma5 += matriz[i][j];
                media[i=4] = soma5 / 4;
            }
            else if(i==5){
                soma6 += matriz[i][j];
                media[i=5] = soma6 / 4;
            }
            else if(i==6){
                soma7 += matriz[i][j];
                media[i=6] = soma7 / 4;
            }
            else if(i==7){
                soma8 += matriz[i][j];
                media[i=7] = soma8 / 4;
            }
            else if(i==8){
                soma9 += matriz[i][j];
                media[i=8] = soma9 / 4;
            }
            else if(i==9){
                soma += matriz[i][j];
                media[i=9] = soma / 4;
            }
        }
    }
    printf("\nMedia das notas dos alunos:\n\n");
    for(i=0;i<10;i++){
        printf("Aluno %d : %.2f ponto(s)\n",i+1,media[i]);
    }

    /*printf("\nMatriz Criada: \n");
    for(i=0;i<10;i++){
        for(j=0;j<4;j++){
            printf("%d \t",matriz[i][j]);
        }
        printf("\n");
    }
    */

    return 0;
}
