#include<stdio.h>

//Aluna: Taiane Aparecida Rodrigues  2� Periodo de SI

/*4 Implemente um programa que declare uma matriz quadrada de 5 linhas por 5
colunas e verifique se a matriz � sim�trica com rela��o � diagonal principal. A matriz
sim�trica � aquela em que todos os elementos A( i , j) = A( j , i) para quaisquer valores
de i e j. Assim, A[2,1] dever� ser igual a A[1,2], e A[3,5] dever� ser igual a A[5,3] e assim
por diante. Imprimir mensagem �Matriz Sim�trica� ou �Matriz n�o Sim�trica�. */

int main(){

    int matriz[5][5],i,j,cont=0;

    for(i=0;i<5;i++){
        for(j=0;j<5;j++){
            printf("Digite o elemento: ");
            scanf("%d",&matriz[i][j]);
        }
    }

    for(i=0;i<5;i++){
        for(j=0;j<5;j++){
            if(matriz[i][j] == matriz[j][i]){
                cont++;
            }
        }
    }

    if(cont == 25){
        printf("\n\n Matriz Simetrica! \n");
    }else{
        printf("\n\n Matriz Nao Simetrica! \n");
    }

    /*printf("\nMatriz Criada: \n");
    for(i=0;i<5;i++){
        for(j=0;j<5;j++){
            printf("%d \t",matriz[i][j]);
        }
        printf("\n");
    }*/

    return 0;
}
