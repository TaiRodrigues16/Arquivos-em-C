#include<stdio.h>

//Aluna: Taiane Aparecida Rodrigues  2� Periodo de SI

/* 1 Fa�a um programa que:
a) leia os n�meros da primeira linha de uma matriz 5x5
b) determine o valor dos demais elementos desta matriz, sabendo que os elementos
das demais linhas consistem no resultado da multiplica��o de cada elemento da linha
anterior pelo valor 2;
c) Exiba a matriz criada. */

int main(){

    int matriz[5][5],i,j;

    for(i=0;i<5;i++){
        for(j=0;j<5;j++){
            if(i==0){
                printf("Digite um numero: ");
                scanf("%d",&matriz[i][j]);
            }
        }
    }

    for(i=0;i<5;i++){
        for(j=0;j<5;j++){
            if(i!=0){
                matriz[i][j] = matriz[i-1][j] * 2;
            }
        }
    }

    printf("\nMatriz Criada: \n");
    for(i=0;i<5;i++){
        for(j=0;j<5;j++){
            printf("%d \t",matriz[i][j]);
        }
        printf("\n");
    }

    return 0;
}
