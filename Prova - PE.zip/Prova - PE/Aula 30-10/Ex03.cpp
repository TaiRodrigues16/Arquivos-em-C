#include<stdio.h>

//Aluna: Taiane Aparecida Rodrigues  2� Periodo de SI

/*3 - Leia uma matriz quadrada 5X5, de n�meros inteiros. Verificar quantos n�meros da
diagonal principal s�o �mpares, escrever quantos s�o �mpares e escrever, tamb�m, a
soma e a m�dia desses elementos. */

int main(){

    int matriz[5][5],i,j,cont=0,soma=0;
    float media;

    for(i=0;i<5;i++){
        for(j=0;j<5;j++){
            printf("Digite os elementos: ");
            scanf("%d",&matriz[i][j]);
        }
    }

    for(i=0;i<5;i++){
        for(j=0;j<5;j++){
            if(i==j){
                if(matriz[i][j] % 2 != 0){
                    soma += matriz[i][j];
                    cont++;
                }
            }
        }
    }

    media = soma / cont;

    printf("\n\nSao %d numeros impares na diagonal principal! \n",cont);
    printf("A soma dos numeros impares na diagonal principal eh: %d \n",soma);
    printf("A media aritmetica dos numeros impares na diagonal principal eh: %.2f \n",media);

    /*printf("\nMatriz Criada: \n");
    for(i=0;i<5;i++){
        for(j=0;j<5;j++){
            printf("%d \t",matriz[i][j]);
        }
        printf("\n");
    }*/

    return 0;
}
