#include<stdio.h>

//Trabalho M�e Dinga

int main(){

    char mamifero,quadrupede,carnivoro,herbivoro,bipedes,onivoro,frutifero,voador,marinho,ave,voa,nadador,rapina,tropical,polar,reptil,casco,RepCarn,SemPatas;

    printf("MAE DINGA TEM O PODER DE DESCOBRIR O QUE VOCE ESTA PENSANDO !!!");
    printf("\nESCOLHA ENTRE OS ANIMAIS ABAIXO RELACIONADOS E MEMORIZE APENAS UM DELES E NAO MUDE MAIS.\n");
    printf("\n    ANIMAIS: \n");
    printf("\n    TIGRE");
    printf("\n    GIRAFA");
    printf("\n    HOMEM");
    printf("\n    MACACO");
    printf("\n    MORCEGO");
    printf("\n    BALEIA");
    printf("\n    AVESTRUZ");
    printf("\n    PINGUIM");
    printf("\n    PATO");
    printf("\n    AGUIA");
    printf("\n    TARTARUGA");
    printf("\n    CROCODILO");
    printf("\n    COBRA \n");

    printf("\nVamos descobrir o seu animal! \nResponda com: S -> Sim ou N -> Nao");
    printf("\nSeu animal eh um mamifero? \n");
    scanf("%s",&mamifero);

    if(mamifero == 's'){
       printf("\nSeu animal eh um Quadrupedes? \n");
       scanf("%s",&quadrupede);

       if(quadrupede == 's'){
           printf("\nSeu animal eh um Carnivoro? \n");
           scanf("%s",&carnivoro);

           if(carnivoro == 's'){
                printf("\nSeu animal eh: Tigre\n");
           }
           else{
                printf("\nSeu animal eh um Herbivoro? \n");
                scanf("%s",&herbivoro);
                if(herbivoro == 's'){
                    printf("\nSeu animal eh: Girafa\n");
                }
                else{
                    printf("\nO animal em questao nao consta na lista! \n");
                }
           }
        }
        else{
            printf("\nSeu animal eh um Bipedes? \n");
            scanf("%s",&bipedes);

            if(bipedes == 's'){
                printf("\nSeu animal eh um Onivoro? \n");
                scanf("%s",&onivoro);
                if(onivoro == 's'){
                    printf("\nSeu animal eh: Homem\n");
                }
                else{
                    printf("\nSeu animal eh um Frutifero? \n");
                    scanf("%s",&frutifero);
                    if(frutifero == 's'){
                        printf("\nSeu animal eh: Macaco\n");
                    }
                    else{
                        printf("\nO animal em questao nao consta na lista! \n");
                    }
                }
            }
            else{
                printf("\nSeu animal eh um Voador? \n");
                scanf("%s",&voador);
                if(voador == 's'){
                    printf("\nSeu animal eh: Morcego\n");
                }
                else{
                    printf("\nSeu animal eh um Marinho? \n");
                    scanf("%s",&marinho);
                    if(marinho == 's'){
                        printf("\nSeu animal eh: Baleia\n");
                    }
                    else{
                        printf("\nO animal em questao nao consta na lista! \n");
                    }
                }
            }
        }
    }
    else{
       printf("\nSeu animal eh uma Ave? \n");
       scanf("%s",&ave);

       if(ave == 's'){
            printf("\nSeu animal Voa? \n");
            scanf("%s",&voa);
            if(voa == 's'){
                printf("\nSeu animal eh um Nadador? \n");
                scanf("%s",&nadador);
                if(nadador == 's'){
                    printf("\nSeu animal eh: Pato\n");
                }
                else{
                    printf("\nSeu animal eh de Rapina? \n");
                    scanf("%s",&rapina);
                    if(rapina == 's'){
                        printf("\nSeu animal eh: Aguia\n");
                    }
                    else{
                        printf("\nO animal em questao nao consta na lista! \n");
                    }
                }
            }
            else{
                printf("\nSeu animal eh de clima tropical ? \n");
                scanf("%s",&tropical);
                if(tropical == 's'){
                    printf("\nSeu animal eh: Avestruz\n");
                }
                else{
                    printf("\nSeu animal eh de clima polar? \n");
                    scanf("%s",&polar);
                    if(polar == 's'){
                        printf("\nSeu animal eh: Pinguim\n");
                    }
                    else{
                        printf("\nO animal em questao nao consta na lista! \n");
                    }
                }
            }
       }
       else{
            printf("\nSeu animal eh um Reptil? \n");
            scanf("%s",&reptil);
            if(reptil == 's'){
               printf("\nSeu animal eh com casco? \n");
               scanf("%s",&casco);
               if(casco == 's'){
                    printf("\nSeu animal eh: Tartaruga\n");
               }
               else{
                    printf("\nSeu animal eh Carnivoro? \n");
                    scanf("%s",&RepCarn);
                    if(RepCarn == 's'){
                        printf("\nSeu animal eh: Crocodilo\n");
                    }
                    else{
                        printf("\nSeu animal eh sem patas? \n");
                        scanf("%s",&SemPatas);
                        if(SemPatas == 's'){
                           printf("\nSeu animal eh: Cobra\n");
                        }
                        else{
                            printf("\nO animal em questao nao consta na lista! \n");
                        }
                    }
               }
            }
            else{
                printf("\nO animal em questao nao consta na lista! \n");
            }
       }
    }

    return 0;
}
